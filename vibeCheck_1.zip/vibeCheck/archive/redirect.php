<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User's Top Artists</title>
</head>
<body>
    <h1>SUCCESSSSSS MOTHERFUCKERSSSS</h1>
     <?php
      echo "<h2>artists</h2>";
      echo $_POST["formArtists"];
      echo "<h2>artist IDs</h2>";
      echo $_POST["formArtistsID"];
      echo "<h2>related artists</h2>";
      echo $_POST["formRelatedArtists"];
      echo "<h2>related artist IDs</h2>";
      echo $_POST["formRelatedArtistsID"];
     ?>

</body>
</html>
